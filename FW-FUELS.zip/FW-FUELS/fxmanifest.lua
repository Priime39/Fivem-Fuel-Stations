fx_version 'cerulean'
games { 'gta5' }

author 'Frank Williams'
description 'FiveM Fuel Stations'
version '1.0.0'

this_is_a_map 'yes'
